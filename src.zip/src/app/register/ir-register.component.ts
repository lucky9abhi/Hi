import {Component} from '@angular/core';
import {Router} from "@angular/router";
import {UserService} from "../_services/user.service";
import {AlertService} from "../_services/alert.service";
import {MdDialog} from "@angular/material";
import {FeedbackComponent} from "../login/feedback/feedback.component";

@Component({
  selector: 'ir-register',
  templateUrl: 'ir-register.component.html'
})

export class RegisterComponent {
  model: any = {};
  loading = false;

  constructor(
    private router: Router,
    public dialog: MdDialog,
    private userService: UserService,
    private alertService: AlertService) { }

  register() {
    this.loading = true;
    this.userService.create(this.model)
      .subscribe(
        data => {
          this.alertService.success('Registration successful', true);
          this.router.navigate(['/login']);
        },
        error => {
          this.alertService.error(error);
          this.loading = false;
        });
  }

  roles = [
    {value: 'sample 1', viewValue: 'Sample-1'},
    {value: 'sample-2', viewValue: 'Sample-2'},
    {value: 'sample-3', viewValue: 'Sample-3'}
  ];

  openDialog() {
    this.dialog.open(FeedbackComponent);
  }

}
