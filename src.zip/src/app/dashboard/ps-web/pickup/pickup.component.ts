import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pickup',
  templateUrl: 'pickup.html'
})
export class PickupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
