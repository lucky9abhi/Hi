import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-storedetails',
  templateUrl: 'storeDetails.html'
})
export class StoreDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
