import { Component, OnInit } from '@angular/core';
import {MdDialog} from "@angular/material";

@Component({
  selector: 'app-machinelisting',
  templateUrl: 'machineListing.html'
})
export class MachineListingComponent implements OnInit {

  constructor(public dialog: MdDialog) { }

  openDialog() {
    this.dialog.open(MachineListingComponent);
  }

  ngOnInit() {
  }

}
