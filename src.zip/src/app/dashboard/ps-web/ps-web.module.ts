import {NgModule} from '@angular/core';
import {RouterModule} from "@angular/router";
import {FormsModule} from "@angular/forms";
import {BrowserModule} from "@angular/platform-browser";
import {MachineListingComponent} from "./machineListing/machineListing.component";
import {PickupComponent} from "./pickup/pickup.component";
import {StoreDetailsComponent} from "./storeDetails/storeDetails.component";
import {MaterialModule} from "@angular/material";

@NgModule({
  declarations: [
   MachineListingComponent,
    PickupComponent,
    StoreDetailsComponent
  ],
  imports: [
    RouterModule,
     FormsModule,
     BrowserModule,
     MaterialModule,
  ],
  exports: [MachineListingComponent, PickupComponent, StoreDetailsComponent],
  providers: [
  ],
})
export class PswebModule {

  constructor() {
  }

}
