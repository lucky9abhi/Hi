import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'accounts',
  templateUrl: 'accounts.component.html'
})
export class AccountsDataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
