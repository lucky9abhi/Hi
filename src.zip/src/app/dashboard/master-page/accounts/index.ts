export * from './accounts.component';
