import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ps-web',
  templateUrl: 'ps-web.component.html'
})
export class PsWebComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
