import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'groups',
  templateUrl: 'groups.component.html'
})
export class GroupsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
