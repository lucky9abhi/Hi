import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sign-up',
  templateUrl: 'sign-up.component.html'
})
export class SignUpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  roles = [
    {value: 'customer', viewValue: 'Customer'},
    {value: 'retailer', viewValue: 'Retailer'},
    {value: 'distributor', viewValue: 'Distributor'},
    {value: 'admin', viewValue: 'Admin Group'}
  ];

}
