import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'role-mapping',
  templateUrl: 'role-mapping.component.html'
})
export class RoleMappingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
