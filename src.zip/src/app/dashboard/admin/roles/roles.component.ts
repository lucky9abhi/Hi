import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'roles',
  templateUrl: 'roles.component.html'
})
export class RolesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
