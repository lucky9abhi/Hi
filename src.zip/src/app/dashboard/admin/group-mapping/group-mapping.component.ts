import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'group-mapping',
  templateUrl: 'group-mapping.component.html'
})
export class GroupMappingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
