import {NgModule} from '@angular/core';
import {RouterModule} from "@angular/router";
import {HomeComponent} from "./ir-home.component";
import {MaterialModule} from "@angular/material";

@NgModule({
  declarations: [
    HomeComponent
  ],
  imports: [
    RouterModule,
    MaterialModule
  ],
  exports: [HomeComponent],
  providers: [

  ],
})
export class HomeModule {

  constructor() {
  }

}
