import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'ir-home',
  templateUrl: 'ir-home.component.html'
})

export class HomeComponent implements OnInit{
  ngOnInit() {

  }

}
