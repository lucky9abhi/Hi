export * from './forgot.component';
