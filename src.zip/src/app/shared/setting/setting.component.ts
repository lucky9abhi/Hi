import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'setting',
  templateUrl: 'setting.component.html'
})
export class SettingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
